1. build image with the dockerfile
2. Run python backend.py directly
3. check the program to see how to run scripts in the containers
4. class worker-node represents a container.
The scripts implements a merge sort. First start l2_1.py to wait for input, t
hen run l1_1 and l1_2 to provide input.
